# MA3_YMU762_AND_DISCOVERY_F407VG
![Screenshot](/CIRCUIT.jpg)

![Screenshot](/IMG_20190407_202642.jpg)

This all started here (credits go to "Gospodin Riba"):
https://vrtp.ru/index.php?act=categories&CODE=article&article=3718

More:
https://vrtp.ru/index.php?showtopic=30096

Original YouTube video (RepStosw == Gospodin Riba):
https://youtu.be/qqYftv_KT-s

Now... my attempts. I tried it with the Ymu759 (MA-2) first - no success, it does not work, I was not able to initialize the chip properly - apparently there were too many differences and I do not have too much time to reverse engineer ROMs from phones that used this IC.
When I received Ymu762-s, I tried this with Gospodin Riba's code (modified, as I used a different XTAL; also I wanted to use line out instead of the speaker), then I ported this to CubeMX (and added some more features, like live MA-3 register access debug via USB).

Wegi received my second ("hand made in Poland") PCB with MA-3 and all the code I created. That's all.

Results:
https://soundcloud.com/konrad-b-694217055/naariayllove-ymu762

https://soundcloud.com/konrad-b-694217055/bodyandbody-ymu762

