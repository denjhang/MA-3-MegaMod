package enums

type Channel int
